import assert from 'node:assert/strict';
import { execFile as execFileCallback } from 'node:child_process';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { mkdir, readFile, realpath, symlink, writeFile } from 'node:fs/promises';
import { findPackageJSON } from 'node:module';
import { dirname, isAbsolute, join, resolve } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { promisify } from 'node:util';
import { measureColdStartup, DIRECT_IMPORT_BUDGET_MS } from './startup-measurement.mjs';

const root = dirname(fileURLToPath(import.meta.url));
const expected = {
  entry: '1cf8c5f1c6dd020824af15b5c320c05a10b89d173394911eec46433cad39150e',
  measurement: '593bf639ac50a8feae90460504523087ce9fe76c56de28fd81fef35e01680c5c',
  sdk: '8571698d27d098f224e684565fdf7bbcba72c0172b875adf59f0b7c088a94554',
  cli: '48de46271f1aebdcb42edb289d186793f4d0345510e25df0b0bec92251fdd160',
  tuiIndex: '6068ae4207de753d9ec00dbe14aee199e6160d1dea0db9c8a92f65d08ffc6e80',
};
const cohortNames = ['pi-coding-agent', 'chord', 'pi-telemetry', 'pi-agent-core', 'pi-ai', 'pi-codemode', 'pi-durable', 'pi-mcp', 'pi-tui'].map(n => '@earendil-works/' + n);
const tools = ['agent_browser', 'agent_browser_code', 'agent_browser_action', 'agent_browser_qa', 'agent_browser_electron', 'agent_browser_source', 'agent_browser_network_source', 'agent_browser_tools'];
const execFile = promisify(execFileCallback);
const args = process.argv.slice(2);
const planOnly = args[0] === '--plan';
if (planOnly) args.shift();
assert.equal(args.length, 1, 'Usage: node discriminator.mjs [--plan] /operator/verified/immutable93/pi-coding-agent/package.json');
assert.ok(isAbsolute(args[0]), 'Selected SDK manifest must be an operator-supplied absolute path');
assert.equal(process.env.NODE_OPTIONS, undefined, 'Clear inherited NODE_OPTIONS; never preload an active bridge');
assert.equal(process.env.NODE_PATH, undefined, 'Clear inherited NODE_PATH; no alternate resolution');
const sha = async p => createHash('sha256').update(await readFile(p)).digest('hex');
assert.equal(await sha(join(root, 'entry.js')), expected.entry);
assert.equal(await sha(join(root, 'startup-measurement.mjs')), expected.measurement);
const sdkManifest = await realpath(args[0]);
const sdk = JSON.parse(await readFile(sdkManifest, 'utf8'));
assert.equal(sdk.name, cohortNames[0]); assert.equal(sdk.version, '1.4.0');
const sdkFile = join(dirname(sdkManifest), 'dist/index.js');
const cliFile = resolve(dirname(sdkManifest), sdk.bin.pi);
assert.equal(await sha(sdkFile), expected.sdk, 'Wrong immutable fork SDK: stop, do not install/substitute');
assert.equal(await sha(cliFile), expected.cli, 'Wrong immutable fork CLI: stop, do not install/substitute');
const cohort = [];
for (const name of cohortNames) {
  const manifest = name === sdk.name ? sdkManifest : findPackageJSON(name, pathToFileURL(sdkManifest));
  assert.ok(manifest, 'Missing native cohort member: ' + name);
  const data = JSON.parse(await readFile(manifest, 'utf8'));
  assert.equal(data.name, name); assert.equal(data.version, '1.4.0');
  cohort.push({ name, version: data.version, manifest, manifestSha256: await sha(manifest) });
}
const tui = cohort.find(c => c.name === '@earendil-works/pi-tui');
assert.equal(await sha(join(dirname(tui.manifest), 'dist/index.js')), expected.tuiIndex, 'Wrong selected native TUI public entry');
const typeboxManifest = findPackageJSON('typebox', pathToFileURL(sdkManifest));
assert.ok(typeboxManifest, 'Missing native typebox companion');
assert.equal(JSON.parse(await readFile(typeboxManifest, 'utf8')).version, '1.3.37');
const plan = { protocol: 'browser293-macos-discriminator-v1', node: { executable: process.execPath, version: process.version, platform: process.platform, arch: process.arch }, expected, cohort, typeboxManifest, sequence: ['tui','entry','entry','tui','tui','entry'], profileSequence: ['tui','entry'], originalBudgetMs: DIRECT_IMPORT_BUDGET_MS, timingScope: 'fresh Node module state, not cold OS file cache; preflight hashes read bytes but do not import native modules', profilesAreNotBudgetSamples: true };
if (planOnly) { console.log(JSON.stringify(plan, null, 2)); process.exit(0); }
assert.equal(process.platform, 'darwin', 'Mac protocol only; --plan permits read-only identity inspection elsewhere');
assert.equal(process.version, 'v24.22.1', 'Use the coordinator-confirmed existing Node24.22.1; do not install/switch active runtime');
assert.ok(!existsSync(join(root, 'results')), 'Use a fresh input extraction; never overwrite an existing result');
await mkdir(join(root, 'results'));
await mkdir(join(root, 'results/profiles'));
await mkdir(join(root, 'node_modules/@earendil-works'), { recursive: true });
for (const c of cohort) await symlink(dirname(c.manifest), join(root, 'node_modules', c.name), 'dir');
await writeFile(join(root, 'results/plan.json'), JSON.stringify(plan, null, 2), { flag: 'wx' });
const tuiScript = `
const cpuStart = process.cpuUsage();
const threadCpuStart = process.threadCpuUsage();
const start = performance.now();
await import('@earendil-works/pi-tui');
const imported = performance.now();
const cpu = process.cpuUsage(cpuStart);
const threadCpu = process.threadCpuUsage(threadCpuStart);
const os = process.getBuiltinModule('node:os');
console.log(JSON.stringify({ mode: 'tui', moduleUrl: import.meta.resolve('@earendil-works/pi-tui'), importMs: imported-start, totalMs: imported-start, diagnostics: { pid: process.pid, cpuMs: (cpu.user+cpu.system)/1000, mainThreadCpuMs: (threadCpu.user+threadCpu.system)/1000, resources: process.resourceUsage(), hardware: { availableParallelism: os.availableParallelism(), logicalCpus: os.cpus().length, memoryBytes: os.totalmem() }, loadAfter: os.loadavg(), node: { executable: process.execPath, version: process.version, platform: process.platform, arch: process.arch } } }));`;
const report = { ...plan, samples: [], profiled: [], errors: [] };
async function sample(mode, label, profiled) {
  try {
    let value;
    if (mode === 'entry') {
      // Unmodified measurement owner, including its exact existing child/factory counters.
      value = await measureColdStartup('./entry.js', root);
      assert.deepEqual(value.tools, tools); assert.equal(value.events, 8);
      assert.equal(value.identity.entrypoint.sha256, expected.entry);
      assert.equal(value.identity.measurementOwner.sha256, expected.measurement);
      assert.equal(value.identity.host.sdk.sha256, expected.sdk);
      assert.equal(value.identity.host.cli.sha256, expected.cli);
    } else {
      const child = await execFile(process.execPath, ['--input-type=module', '-e', tuiScript], { cwd: root, maxBuffer: 1024*1024, timeout: 10000 });
      value = JSON.parse(child.stdout.trim());
      assert.equal(await sha(fileURLToPath(value.moduleUrl)), expected.tuiIndex);
      if (profiled && child.stderr) await writeFile(join(root, 'results', label + '.stderr.log'), child.stderr, { flag: 'wx' });
    }
    const row = { mode, label, profiled, ...value };
    await writeFile(join(root, 'results', label + '.json'), JSON.stringify(row, null, 2), { flag: 'wx' });
    (profiled ? report.profiled : report.samples).push(row);
  } catch (error) {
    const failure = { mode, label, profiled, error: String(error), stdout: error.stdout, stderr: error.stderr };
    report.errors.push(failure);
    await writeFile(join(root, 'results', label + '.error.json'), JSON.stringify(failure, null, 2), { flag: 'wx' });
    throw error;
  }
}
try {
  for (const [i, mode] of plan.sequence.entries()) await sample(mode, `sample-${i+1}-${mode}`, false);
  for (const mode of plan.profileSequence) {
    // Instrumentation is profile-only. No remote inspector, monkeypatch, SDK callback substitute, or module warmup.
    process.env.NODE_OPTIONS = '--require=' + JSON.stringify(join(root, 'cpu-preload.cjs')) + ' --trace-event-categories=v8,node.module_timer --trace-event-file-pattern=' + JSON.stringify(join(root, 'results/profiles', mode + '-trace-${pid}.json'));
    process.env.BROWSER_CPU_PROFILE_PATH = join(root, 'results/profiles', mode + '.cpuprofile');
    try { await sample(mode, 'profile-' + mode, true); }
    finally { delete process.env.NODE_OPTIONS; delete process.env.BROWSER_CPU_PROFILE_PATH; }
    const profile = JSON.parse(await readFile(join(root, 'results/profiles', mode + '.cpuprofile'), 'utf8'));
    assert.ok(Array.isArray(profile.nodes) && profile.nodes.length > 0);
    const modules = [...new Set(profile.nodes.map(n => n.callFrame.url).filter(Boolean))].sort();
    await writeFile(join(root, 'results', 'profile-' + mode + '.sampled-modules.json'), JSON.stringify({ scope: 'V8 sampled frame URLs, not a complete loader graph', modules }, null, 2), { flag: 'wx' });
  }
} finally {
  report.withinOriginalBudget = report.samples.filter(s => s.mode === 'entry').length === 3 && report.samples.filter(s => s.mode === 'entry').every(s => s.totalMs < DIRECT_IMPORT_BUDGET_MS);
  await writeFile(join(root, 'results/report.json'), JSON.stringify(report, null, 2), { flag: 'wx' });
}
console.log(JSON.stringify({ results: join(root, 'results'), withinOriginalBudget: report.withinOriginalBudget, samples: report.samples.map(s => ({ mode:s.mode,totalMs:s.totalMs,cpuMs:s.diagnostics.cpuMs,mainThreadCpuMs:s.diagnostics.mainThreadCpuMs })) }, null, 2));
if (!report.withinOriginalBudget) process.exitCode = 1;
