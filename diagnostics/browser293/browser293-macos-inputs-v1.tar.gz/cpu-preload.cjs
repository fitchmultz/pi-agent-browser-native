// Diagnostic-only in-process V8 Inspector session. No inspector.open(), listener, or remote target.
const { Session } = require('node:inspector');
const { writeFileSync } = require('node:fs');
const path = process.env.BROWSER_CPU_PROFILE_PATH;
if (!path) throw new Error('Missing owned CPU profile output path');
const session = new Session();
session.connect();
session.post('Profiler.enable');
session.post('Profiler.start');
process.once('beforeExit', () => {
  session.post('Profiler.stop', (error, result) => {
    if (error) throw error;
    writeFileSync(path, JSON.stringify(result.profile), { flag: 'wx' });
    session.disconnect();
  });
});
